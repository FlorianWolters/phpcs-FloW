
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","FloW_Sniffs_Commenting_DisallowHashCommentsSniff"],["c","FloW_Sniffs_Files_FileExtensionIsPhpSniff"],["c","FloW_Sniffs_PHP_DisallowCloseTagSniff"],["c","FloW_Sniffs_PHP_DisallowDataBeforeOpenTagSniff"],["c","FloW_Sniffs_PHP_DisallowMultipleOpenTagsSniff"]];
